﻿namespace MusicStore.ViewModels
{
    public class AlbumData
    {
        public string Title { get; set; }

        public string Url { get; set; }
    }
}