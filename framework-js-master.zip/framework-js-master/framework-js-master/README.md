
## Instalation

assurez vous que votre `.npmrc` resemble a :

    strict-ssl=false
    shrinkwrap=false
    cafile=D:\dev\applications\node-v12.10.0-win-x64\assu.pem
    python=D:\dev\applications\python\Python37-32\python.exe
    noproxy=*.assu.socgen
    sass-binary-site=http://integrationcontinue.assu.socgen/node-sass
    always-auth=true
    registry=https://binaires.assu.socgen:8443/repository/npm-assu/


### Installation de yarn

en console 

    npm install yarn -g

### Installation de lerna

en console

    npm install lerna -g


### le projet

en console 

    yarn install


    openssl config failed: error:02001003:system library:fopen:No such process
    yarn install v1.22.4
    (node:28924) Warning: Setting the NODE_TLS_REJECT_UNAUTHORIZED environment variable to '0' makes TLS connections and HTTPS requests insecure by disabling certificate verification.
    [1/4] 🔍  Resolving packages...
    info There appears to be trouble with your network connection. Retrying...
    [2/4] 🚚  Fetching packages...
    info There appears to be trouble with your network connection. Retrying...
    info There appears to be trouble with your network connection. Retrying...
    info There appears to be trouble with your network connection. Retrying...
    info fsevents@2.1.2: The platform "win32" is incompatible with this module.
    info "fsevents@2.1.2" is an optional dependency and failed compatibility check. Excluding it from installation.
    info fsevents@1.2.12: The platform "win32" is incompatible with this module.
    info "fsevents@1.2.12" is an optional dependency and failed compatibility check. Excluding it from installation.
    [3/4] 🔗  Linking dependencies...
    warning " > listr-update-renderer@0.5.0" has unmet peer dependency "listr@^0.14.2".
    warning " > @assu-bootstrap/css@1.0.8" has unmet peer dependency "jquery@1.9.1 - 3".
    warning " > @assu-bootstrap/css@1.0.8" has unmet peer dependency "popper.js@^1.14.4".
    warning "workspace-aggregator-3320955b-3414-4fe2-8bd1-be2e1b471a3d > @assu-bootstrap/css > bootstrap@4.4.1" has unmet peer dependency "jquery@1.9.1 - 3".
    warning "workspace-aggregator-3320955b-3414-4fe2-8bd1-be2e1b471a3d > @assu-bootstrap/css > bootstrap@4.4.1" has unmet peer dependency "popper.js@^1.16.0".
    warning "workspace-aggregator-3320955b-3414-4fe2-8bd1-be2e1b471a3d > @assu-bootstrap/css > ts-jest@25.3.1" has incorrect peer dependency "jest@>=25 <26".
    [4/4] 🔨  Building fresh packages...
    success Saved lockfile.
    $ yarn run haxx:lerna
    openssl config failed: error:02001003:system library:fopen:No such process
    yarn run v1.22.4
    $ node scripts/haxx-lerna-publish-npm-user-name.js
    ✨  Done in 0.70s.
    ✨  Done in 69.48s.


## compilation après modification

en console 

    yarn build

    openssl config failed: error:02001003:system library:fopen:No such process
    yarn run v1.22.4
    $ lerna run build
    lerna notice cli v3.20.2
    lerna info Executing command in 1 package: "yarn run build"
    lerna info run Ran npm script 'build' in '@assu-bootstrap/css' in 13.9s:
    $ npm-run-all -s clear build:*
    $ rimraf build/
    $ npm-run-all -s compile:css prefix:css -p minify:css:* -s
    $ node-sass scss -o build/ --precision 7 --outputStyle "expanded" --include-path "../../node_modules" --source-map true 2>&1
    Rendering Complete, saving .css file...
    Wrote CSS to D:\dev\repository\fwk-css\@assu-bootstrap\css\build\assu-bootstrap-extension.css
    Wrote Source Map to D:\dev\repository\fwk-css\@assu-bootstrap\css\build\assu-bootstrap-extension.css.map
    Wrote 1 CSS files to D:\dev\repository\fwk-css\@assu-bootstrap\css\build\
    $ postcss --config postcss.config.js --replace "build/*.css" "!build/*.min.css"
    $ cleancss --level 1 --source-map --source-map-inline-sources --output build/assu-bootstrap-extension.min.css build/assu-bootstrap-extension.css
    lerna success run Ran npm script 'build' in 1 package in 13.9s:
    lerna success - @assu-bootstrap/css
    ✨  Done in 15.91s.


## deploiement

en console 

    yarn deploy



## utilisation 

Dans l'application cible.

dans le fichier `package.json`


    "dependencies": {
        ....
        "@assu-bootstrap/css": "^1.0.10",
        ....


dans le fichier `angular.json`


    "assets": [
        "src/favicon.ico",
        "src/assets",
        {
        "glob": "**/*",
        "input": "./node_modules/@assu-bootstrap/css/assets",
        "output": "./assets/"
        }
    ],
    "styles": [
        "src/styles/global-styles.scss",
        "node_modules/@assu-bootstrap/css/build/assu-bootstrap-extension.css",
        "node_modules/@fortawesome/fontawesome-free/css/all.css"
    ],
    "stylePreprocessorOptions": {
        "includePaths": [
        "src/styles"
        ]
    },
    "scripts": [
            "node_modules/jquery/dist/jquery.min.js",
            "node_modules/popper.js/dist/umd/popper.min.js",
            "node_modules/bootstrap/dist/js/bootstrap.min.js"
    ],