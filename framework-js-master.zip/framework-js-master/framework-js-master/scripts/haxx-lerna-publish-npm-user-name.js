//

//
// HACK(dduteil092115): Remove Lerna getNpmUsername from existence
// This is HAXX bypass the `getNpmUsername` check introduced in
// `@lerna/publish@3.4.0`
// see https://github.com/lerna/lerna/blob/v3.4.0/commands/publish/index.js#L79
//

require('shelljs').sed(
  '-i',
  /^(\s+)chain = chain.then\(\(\) => getNpmUsername\(this.conf\)\);$/,
  ``,
  'node_modules/@lerna/publish/index.js'
);
