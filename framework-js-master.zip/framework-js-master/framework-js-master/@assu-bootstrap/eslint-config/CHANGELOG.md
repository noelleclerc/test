# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.30](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.30) (2020-04-30)

**Note:** Version bump only for package @assu-bootstrap/eslint-config





## [1.0.29](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.29) (2020-04-30)

**Note:** Version bump only for package @assu-bootstrap/eslint-config





## [1.0.28](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.28) (2020-04-29)

**Note:** Version bump only for package @assu-bootstrap/eslint-config





## [1.0.27](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.27) (2020-04-29)

**Note:** Version bump only for package @assu-bootstrap/eslint-config





## [1.0.25](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.25) (2020-04-29)

**Note:** Version bump only for package @assu-bootstrap/eslint-config
