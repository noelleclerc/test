import { ModuleWithProviders } from '@angular/core';
export { AuthGuard } from './auth.guard';
export { AppAuth } from './auth.service';
export { LinkAssuHttpInterceptor } from './linkassuhttpinterceptor';
export { AuthIndirection, AUTH_INDIRECTION } from './auth.indirection';
export declare class AuthModule {
    static forRoot(): ModuleWithProviders;
}
