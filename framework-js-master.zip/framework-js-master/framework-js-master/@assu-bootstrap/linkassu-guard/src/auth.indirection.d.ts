import { InjectionToken } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
/**
 * Jeton d'injection des indirections d'authentification
 */
export declare const AUTH_INDIRECTION: InjectionToken<AuthIndirection>;
/**
 * Permet de définir un comportement à adopter en cas de refus d'authentification,
 * Typiquement une redirection vers LinkAssu
 */
export interface AuthIndirection {
    /**
     * Méthode invoqué par AuthGuard si l'authentification a échoué
     */
    indirection(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any;
}
