export declare class StorageService {
    private timeout;
    constructor();
    write(key: string, value: any): void;
    read<T>(key: string): T;
}
