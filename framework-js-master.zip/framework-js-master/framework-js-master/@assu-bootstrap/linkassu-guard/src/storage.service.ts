import { Injectable } from '@angular/core';

/*
* Storage Service Component : Permet de gérer les données stockées côté client
*/
@Injectable()
export class StorageService {
    private timeout: number;

    constructor(
    ) {
        this.timeout = 1800; // AppModule.conf.storage_timeout;
    }

    write(key: string, value: any) {
        if (value) {
            let expirationDate = new Date();
            expirationDate.setSeconds(expirationDate.getSeconds() + this.timeout);

            let data = { expirationDate: expirationDate, value: value };
            value = JSON.stringify(data);
        }

        sessionStorage.setItem(key, value);
    }

    read<T>(key: string): T {
        let value: string = sessionStorage.getItem(key);

        if (value && value !== 'undefined' && value !== 'null') {
            let data = JSON.parse(value);

            let now = new Date();
            let expirationDate = new Date(data.expirationDate);

            if (now.getTime() < expirationDate.getTime()) {
                // repousse la date d'expiration de la valeur dans le session storage
                this.write(key, data.value);

                return <T>data.value;
            } else {
                sessionStorage.removeItem(key);
            }
        }

        return null;
    }
}
