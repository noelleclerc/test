import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AppAuth } from './auth.service';
import { AuthIndirection } from './auth.indirection';
/**
 * Guard Angular permettant de vérifier la présence des jetons d'authentification dans l'URL,
 * de récupérer ces jetons et de les conserver pour usage par l'intercepteur HTTP
 */
export declare class AuthGuard implements CanActivate {
    private appAuth;
    private router;
    private indirection;
    /**
     * @param appAuth Service de stockage des informations d'authentification
     * @param indirection Classe implantant les opérations à réaliser en cas de refus d'authentification
     */
    constructor(appAuth: AppAuth, router: Router, indirection: AuthIndirection);
    /**
     * Vérifie la présence des jetons d'authentification et les stocke si ceux-ci sont valides.
     * Délègue le comportement en cas de refus d'authentification.
     */
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    /**
     * Extrait un paramètre de l'URL
     * @param name Nom du paramètre
     * @param url URL de laquelle extraire le paramètre
     */
    getParameterByName(name: any, url?: string): string;
    /**
     * Supprime le paramètre name de l'url
     * @param name Nom du paramètre à supprimer
     * @param url URL dans laquelle supprimer le paramètre
     */
    removeParameterByName(name: any, url?: string): string;
}
