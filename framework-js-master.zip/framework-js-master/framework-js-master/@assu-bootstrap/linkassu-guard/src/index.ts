import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AuthGuard } from './auth.guard';
import { AppAuth } from './auth.service';
import { StorageService } from './storage.service';
import { LinkAssuHttpInterceptor } from './linkassuhttpinterceptor';

export { AuthGuard } from './auth.guard';
export { AppAuth } from './auth.service';
export { LinkAssuHttpInterceptor } from './linkassuhttpinterceptor';
export { AuthIndirection, AUTH_INDIRECTION } from './auth.indirection';

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
    ],
    providers: [
        AuthGuard,
        AppAuth,
        StorageService,
        LinkAssuHttpInterceptor
    ]
})
/**
 * Module regroupant les fonctionnalités LinkAssu/Angular pour une intégration facilitée dans les applications utilisatrices
 */
export class AuthModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: AuthModule
        };
    }
}
