import { StorageService } from './storage.service';
/**
 * Service permettant de persister dans le localstorage les infos d'authentification
 */
export declare class AppAuth {
    private storageService;
    /**
     * @param storageService Service de persistence sur lequel s'appuyer
     */
    constructor(storageService: StorageService);
    loginSSO(): void;
    /**
     * Supprime les infos d'authentification du localstorage
     */
    logout(): void;
    /**
     * Indique si l'utilisateur est authentifié
     */
    getAuth(): boolean;
    /**
     * Retourne le jeton d'identification
     */
    getAuthToken(): string;
    /**
     * Retourne le jeton d'authentification
     */
    getAuthJwtToken(): string;
    /**
     * Définit le jeton d'identification
     * @param authToken Jeton d'identification
     */
    setAuthToken(authToken: string): void;
    /**
     * Définit le jeton d'authentification
     * @param authToken Jeton d'authentification
     */
    setAuthJwtToken(authToken: string): void;
    isAuthSSO(): boolean;
    setAuthSSO(authSSO: boolean): void;
    /**
     * Indique si l'utilisateur est authentifié
     */
    isAuth(): boolean;
    /**
     * Définit si l'utilisateur est authentifié
     * @param auth Etat d'authentification de l'utilisateur
     */
    setAuth(auth: boolean): void;
}
