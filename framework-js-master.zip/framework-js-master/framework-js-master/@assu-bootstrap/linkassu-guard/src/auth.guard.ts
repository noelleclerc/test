import { Injectable, Inject, Optional } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AppAuth } from './auth.service';
import { AuthIndirection, AUTH_INDIRECTION } from './auth.indirection';

/**
 * Guard Angular permettant de vérifier la présence des jetons d'authentification dans l'URL,
 * de récupérer ces jetons et de les conserver pour usage par l'intercepteur HTTP
 */
@Injectable()
export class AuthGuard implements CanActivate {
    /**
     * @param appAuth Service de stockage des informations d'authentification
     * @param indirection Classe implantant les opérations à réaliser en cas de refus d'authentification
     */
    constructor(
        private appAuth: AppAuth,
        private router: Router,
        @Inject(AUTH_INDIRECTION) @Optional() private indirection: AuthIndirection) { }

    /**
     * Vérifie la présence des jetons d'authentification et les stocke si ceux-ci sont valides.
     * Délègue le comportement en cas de refus d'authentification.
     */
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        /**
         * On récupère les paramètres en accédant directement à l'URL du navigateur car le routeur Angular peut, selon sa configuration,
         * ne pas récupérer ces paramètres.
         * En particulier si le routeur est en mode "useHash".
         */
        let queryParams = document.location.search + document.location.hash;
        let tokenInUrl = this.getParameterByName('token', queryParams);
        let jwtInUrl = this.getParameterByName('jwt', queryParams);
        if (!this.appAuth.getAuth() && tokenInUrl) {
            this.appAuth.setAuth(true);
            this.appAuth.setAuthSSO(true);
            this.appAuth.setAuthToken(tokenInUrl);
            this.appAuth.setAuthJwtToken(jwtInUrl);

            // Supprimer les jetons de l'URL
            /**
             * On supprime les paramètres en accédant directement à l'URL du navigateur car le routeur Angular peut, selon sa configuration,
             * ne pas récupérer ces paramètres.
             * En particulier si le routeur est en mode "useHash".
             */
            let url = document.location.href;
            url = this.removeParameterByName('token', url);
            url = this.removeParameterByName('jwt', url);
            console.log('Suppression des param�tres token et jwt dans l\'URL');
            document.location.replace(url);
            // Si le hash contient les jetons, on les supprime
            let hash = document.location.hash.substring(1);
            hash = this.removeParameterByName('token', hash);
            hash = this.removeParameterByName('jwt', hash);
            this.router.navigateByUrl(hash);
            return false;
        }

        if (!this.appAuth.getAuth()) {
            if (this.indirection != null) {
                this.indirection.indirection(route, state);
            }
            return false;
        }

        return true;
    }

    /**
     * Extrait un paramètre de l'URL
     * @param name Nom du paramètre
     * @param url URL de laquelle extraire le paramètre
     */
    getParameterByName(name, url = window.location.href): string {
        name = name.replace(/[\[\]]/g, '\\$&');
        let regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'), results = regex.exec(url);
        if (!results) {
            return null;
        }
        if (!results[2]) {
            return '';
        }
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    /**
     * Supprime le paramètre name de l'url
     * @param name Nom du paramètre à supprimer
     * @param url URL dans laquelle supprimer le paramètre
     */
    removeParameterByName(name, url = window.location.href): string {
        let regex = new RegExp('[?&]' + name + '=[^&#]*');
        return url.replace(regex, '');
    }
}
