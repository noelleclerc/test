import { HttpHandler, HttpInterceptor, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppAuth } from './auth.service';
/**
 * Intercepteur HTTP compatible Angular 5 (@angular/common/http) permettant d'ajouter les entêtes
 * d'authentification aux requetes HTTP sortantes :
 *  - Authorization
 *  - X-FactorToken
 */
export declare class LinkAssuHttpInterceptor implements HttpInterceptor {
    private appAuth;
    /**
     * Nécessite le service AppAuth offrant la capacité de conserver les informations d'authentification le temps de
     * l'utilisation de l'application
     */
    constructor(appAuth: AppAuth);
    /**
     * Ajoute les entêtes d'authentification aux requetes HTTP sortantes
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
}
