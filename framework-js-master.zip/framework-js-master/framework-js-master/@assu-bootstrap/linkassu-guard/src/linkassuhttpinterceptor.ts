import { Injectable } from '@angular/core';
import { HttpHandler, HttpInterceptor, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppAuth } from './auth.service';


/**
 * Intercepteur HTTP compatible Angular 5 (@angular/common/http) permettant d'ajouter les entêtes
 * d'authentification aux requetes HTTP sortantes :
 *  - Authorization
 *  - X-FactorToken
 */
@Injectable()
export class LinkAssuHttpInterceptor implements HttpInterceptor {

    /**
     * Nécessite le service AppAuth offrant la capacité de conserver les informations d'authentification le temps de
     * l'utilisation de l'application
     */
    constructor(private appAuth: AppAuth) { }

    /**
     * Ajoute les entêtes d'authentification aux requetes HTTP sortantes
     */
    intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        const token: string = this.appAuth.getAuthToken();
        const tokenJwt: string = this.appAuth.getAuthJwtToken();
        let nextRequest = request;
        if (!!token) {
            nextRequest = request.clone({
                headers: request.headers.set('Authorization', `Bearer ${token}`).set('X-FactorToken', tokenJwt),
                withCredentials: true
            });
        }
        return next
            .handle(nextRequest)
            .pipe(catchError(response => {
                return Observable.throw(response);
            }));
    }

}
