import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';

/**
 * Service permettant de persister dans le localstorage les infos d'authentification
 */
@Injectable()
export class AppAuth {
    /**
     * @param storageService Service de persistence sur lequel s'appuyer
     */
    constructor(private storageService: StorageService) {
    }

    public loginSSO() {
        this.setAuthSSO(true);
    }

    /**
     * Supprime les infos d'authentification du localstorage
     */
    public logout() {
        sessionStorage.clear();
    }

    /**
     * Indique si l'utilisateur est authentifié
     */
    public getAuth(): boolean {
        return this.isAuth();
    }

    /**
     * Retourne le jeton d'identification
     */
    public getAuthToken(): string {
        return this.storageService.read<string>('auth_token');
    }

    /**
     * Retourne le jeton d'authentification
     */
    public getAuthJwtToken(): string {
        return this.storageService.read<string>('jwtToken');
    }

    /**
     * Définit le jeton d'identification
     * @param authToken Jeton d'identification
     */
    public setAuthToken(authToken: string) {
        this.storageService.write('auth_token', authToken);
    }

    /**
     * Définit le jeton d'authentification
     * @param authToken Jeton d'authentification
     */
    public setAuthJwtToken(authToken: string) {
        this.storageService.write('jwtToken', authToken);
    }

    public isAuthSSO(): boolean {
        return (this.storageService.read('authSSO') === true);
    }

    public setAuthSSO(authSSO: boolean) {
        this.storageService.write('authSSO', authSSO);
    }

    /**
     * Indique si l'utilisateur est authentifié
     */
    public isAuth(): boolean {
        return (this.storageService.read('auth') === true);
    }

    /**
     * Définit si l'utilisateur est authentifié
     * @param auth Etat d'authentification de l'utilisateur
     */
    public setAuth(auth: boolean) {
        this.storageService.write('auth', auth);
    }
}
