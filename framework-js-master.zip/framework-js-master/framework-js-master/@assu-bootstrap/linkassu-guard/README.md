# LinkAssu Angular Guard

Module Angular 5 d'authentification LinkAssu : le but est de fournir un mécanisme commun de récupération des paramètres d'authentification LinkAssu depuis l'URL (paramètres `token` et `jwt`).

Ce module a été initialisé avec le générateur https://github.com/jvandemo/generator-angular2-library.

## Utilisation du module
Ce module s'utilise comme une dépendance Angular gérée par `npm` :

### Installation 
A la racine de l'application Angular (où se situe le fichier `package.json`), installer la dépendance :
```bash
npm install @sogecap/linkassu-angular-guard@x.y.z
```

Et d'ajouter le module `AuthModule` aux imports de l'application. Exemple :
```javascript
import { AuthModule } from '@sogecap/linkassu-angular-guard';

@NgModule({
    declarations: [
        ...
    ],
    imports: [
        ...
        AuthModule.forRoot()
    ],
    providers: [
       ...
    ],
    ...
})
export class AppModule { }
```

### Intégration dans une application
L'intégration se décompose en trois étapes dont une optionelle.

#### Mise en place du Guard
Afin de rendre obligatoire l'authentification LinkAssu, il faut déclarer le Guard `AuthGuard` comme filtre des routes de l'application. Exemple :
```javascript
appRoutes = [
    {
        path: 'dossier',
        children: DOSSIER_ROUTES,
        canActivate: [AuthGuard]
    },
    {
        path: 'redirect',
        component: NoOpComponent,
        canActivate: [
            AuthGuard,
            Redirect
        ]
    },
    {
        path: '',
        pathMatch: 'full',
        component: NoOpComponent,
        canActivate: [AuthGuard]
    }
];
```
Toutes les routes nécessitant une authentification LinkAssu doivent avoir `AuthGuard` comme premier filtre de la directive `canActivate`.

#### Entêtes des requêtes sortantes
Afin de permettre aux backends de connaître l'utilisateur à l'origine des requêtes émisent par l'application Angular, il est nécessaire d'ajouter des entêtes HTTP à chaque requête sortante. Cette bibliothèque propose un intercepteur effectuant cette opération. Pour l'activer, il suffit de l'ajouter à la liste des intercepteurs dans la déclaration du module principal de l'application :

```javascript
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LinkAssuHttpInterceptor } from '@sogecap/linkassu-angular-guard';

@NgModule({
    declarations: [
        ...
    ],
    imports: [
        ...
    ],
    providers: [
        ...
        {
            provide: HTTP_INTERCEPTORS,
            useClass: LinkAssuHttpInterceptor,
            multi: true
        }
    ],
    ...
})
export class AppModule { }
```

Les entêtes :
 - Authorization
 - X-FactorToken
seront automatiquement ajoutés.

#### Gestion de l'indirection (optionnel)
Enfin, il est possible de définir la manière dont doit être traité un utilisateur non authentifié. La plupart du temps, on le redirigera vers la mire d'authentification LinkAssu, mais cela reste dépendant du cas d'utilisation.
Par défaut, en cas d'indirection, la bibliothèque ne fait rien de particulier ; ce qui signifie que les requêtes HTTP sortantes n'auront pas d'entêtes supplémentaires et que les routes protégées par `AuthGuard` ne seront pas accessibles.

S'il est nécessaire de rediriger l'utilisateur, il est possible de définir un comportement implantant l'interface `AuthIndirection` dans l'application. Exemple :
```javascript
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthIndirection } from '@sogecap/linkassu-angular-guard'

@Injectable()
export class LoginIndirection implements AuthIndirection {
    
    indirection(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        console.log("Should redirect to LinkAssu");
    }
}
```
Ici, en cas d'indirection, on se contente de logger. Si une redirection d'URL était nécessaire, on pourrait le faire ici.
Pour déclarer ce composant dans le `AuthGuard`, il est nécessaire d'inscrire ce LoginIndirection aux providers du module. Exemple :
```javascript
import { AUTH_INDIRECTION } from '@sogecap/linkassu-angular-guard';

@NgModule({
    declarations: [
        ...
    ],
    imports: [
        ...
    ],
    providers: [
        AppService,
        {
            provide: AUTH_INDIRECTION, 
            useClass: LoginIndirection
        },
        ...
    ],
    ...
})
export class AppModule { }
```

## Publication du module

### .npmrc

Ajouter les options suivantes au .npmrc :
```
registry=https://binaires.assu.socgen:8443/repository/npm-assu/
_auth=*base64 du couple user:pass*
email=*son adresse email*
```

### Publier une SNAPSHOT
Le principe de SNAPSHOT n'étant pas directement pris en charge par npm, on doit gérer les versions SNAPSHOT "à la main".
On a cependant à dispostion quelques outils pour faciliter la manipulation de ces numéros de version.

Il faut d'abord installer les paquets suivants :

```
npm install -g set-version
npm install -g npm-auto-snapshot
```

#### Passer sur une version SNAPSHOT
Avant de pouvoir réaliser une numérotation automatique, il est nécessaire de passer la version en -SNAPSHOT. Cela n'est probablement pas nécessaire sur les branches de développement car celles-ci sont déjà en -SNAPSHOT.

Pour changer le numéro de version :

```
cd src/
v x.y.z-SNAPSHOT
```
Où x, y et z sont les numéros de version voulue.

Ensuite, il est possible d'attribuer un numéro de version unique :

```
npm_update_snapshot src
```
Le numéro de version doit désormais être de la forme : x.y.z-SNAPSHOT.timestamp

#### Publier
Pour publier, il suffit de lancer les commandes suivantes :
```
npm_update_snapshot src
npm run build
npm publish dist
```

### Publier une RELEASE

#### Passer sur une version RELEASE
Une fois le développement d'une branche en SNAPSHOT terminée, on renomme la version pour enlever le -SNAPSHOT :
```
cd src/
v x.y.z
```
Où x, y et z sont les numéros de version voulue.

#### Publier
Pour publier, il suffit de lancer les commandes suivantes :
```
npm run build
npm publish dist
```

## Utilisation dans un projet client

### Dépendance SNAPSHOT
Pour utiliser la dépendance en version SNAPSHOT, il suffit de préciser dans le package.json la version correspondante :
```
npm install @sogecap/linkassu-angular-guard@^x.y.z-SNAPSHOT
```
Où x, y et z correspondent au numéro de la version voulue. Npm ira alors automatiquement chercher la version `x.y.z-SNAPSHOT.timestamp` avec le `timestamp` le plus élevé ; ce qui correspondra à la dernière SNAPSHOT déployée.

### Dépendance RELEASE
La dépendance RELEASE s'utilise comme n'importe quelle dépendance npm :

```
npm install @sogecap/linkassu-angular-guard@x.y.z
```