import resolve from '@rollup/plugin-node-resolve';


export default {
  input: 'dist/src/index.js',
  output: {
    name: "linkassu-guard",
    file: 'dist/bundles/linkassu-guard.umd.js',
    format: 'umd'
  },

  sourceMap: false,
  format: 'umd',
  globals: {
    '@angular/core': 'ng.core',
    'rxjs/Observable': 'Rx',
    'rxjs/ReplaySubject': 'Rx',
    'rxjs/add/operator/map': 'Rx.Observable.prototype',
    'rxjs/add/operator/mergeMap': 'Rx.Observable.prototype',
    'rxjs/add/observable/fromEvent': 'Rx.Observable',
    'rxjs/add/observable/of': 'Rx.Observable'
  },
  plugins: [ resolve() ]
}