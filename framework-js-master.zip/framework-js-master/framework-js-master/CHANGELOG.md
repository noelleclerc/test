# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.43](https://sources.assu.socgen/sms/framework-js/compare/v1.0.42...v1.0.43) (2020-08-12)

**Note:** Version bump only for package assu-css





## [1.0.42](https://sources.assu.socgen/sms/framework-js/compare/v1.0.40...v1.0.42) (2020-08-06)

**Note:** Version bump only for package assu-css





## [1.0.41](https://sources.assu.socgen/sms/framework-js/compare/v1.0.40...v1.0.41) (2020-08-06)

**Note:** Version bump only for package assu-css





## [1.0.40](https://sources.assu.socgen/sms/framework-js/compare/v1.0.39...v1.0.40) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.39](https://sources.assu.socgen/sms/framework-js/compare/v1.0.37...v1.0.39) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.38](https://sources.assu.socgen/sms/framework-js/compare/v1.0.37...v1.0.38) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.37](https://sources.assu.socgen/sms/framework-js/compare/v1.0.36...v1.0.37) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.36](https://sources.assu.socgen/sms/framework-js/compare/v1.0.34...v1.0.36) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.35](https://sources.assu.socgen/sms/framework-js/compare/v1.0.34...v1.0.35) (2020-08-05)

**Note:** Version bump only for package assu-css





## [1.0.34](https://sources.assu.socgen/sms/framework-js/compare/v1.0.33...v1.0.34) (2020-06-19)

**Note:** Version bump only for package assu-css





## [1.0.33](https://sources.assu.socgen/sms/framework-js/compare/v1.0.31...v1.0.33) (2020-05-28)

**Note:** Version bump only for package assu-css





## [1.0.32](https://sources.assu.socgen/sms/framework-js/compare/v1.0.31...v1.0.32) (2020-05-28)

**Note:** Version bump only for package assu-css





## [1.0.31](https://sources.assu.socgen/sms/framework-js/compare/v1.0.30...v1.0.31) (2020-05-07)

**Note:** Version bump only for package assu-css





## [1.0.30](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.30) (2020-04-30)

**Note:** Version bump only for package assu-css





## [1.0.29](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.29) (2020-04-30)

**Note:** Version bump only for package assu-css





## [1.0.28](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.28) (2020-04-29)

**Note:** Version bump only for package assu-css





## [1.0.27](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.27) (2020-04-29)

**Note:** Version bump only for package assu-css





## [1.0.25](https://sources.assu.socgen/sms/framework-js/compare/v1.0.23...v1.0.25) (2020-04-29)

**Note:** Version bump only for package assu-css





## [1.0.23](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.23) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.22](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.22) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.21](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.21) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.20](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.20) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.19](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.19) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.18](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.18) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.17](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.17) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.16](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.16) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.15](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.15) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.14](https://sources.assu.socgen/sms/framework-js/compare/v1.0.13...v1.0.14) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.13](https://sources.assu.socgen/sms/framework-js/compare/v1.0.12...v1.0.13) (2020-04-22)

**Note:** Version bump only for package assu-css





## [1.0.12](https://sources.assu.socgen/sms/framework-js/compare/v1.0.11...v1.0.12) (2020-04-21)

**Note:** Version bump only for package assu-css





## [1.0.11](https://sources.assu.socgen/sms/framework-js/compare/v1.0.7...v1.0.11) (2020-04-10)

**Note:** Version bump only for package assu-css





## [1.0.10](https://sources.assu.socgen/sms/framework-js/compare/v1.0.7...v1.0.10) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.9](https://sources.assu.socgen/sms/framework-js/compare/v1.0.7...v1.0.9) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.8](https://sources.assu.socgen/sms/framework-js/compare/v1.0.7...v1.0.8) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.7](https://sources.assu.socgen/sms/framework-js/compare/v1.0.6...v1.0.7) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.6](https://sources.assu.socgen/sms/framework-js/compare/v1.0.5...v1.0.6) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.5](https://sources.assu.socgen/sms/framework-js/compare/v1.0.4...v1.0.5) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.4](https://sources.assu.socgen/sms/framework-js/compare/v1.0.3...v1.0.4) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.3](https://sources.assu.socgen/sms/framework-js/compare/v1.0.2...v1.0.3) (2020-04-09)

**Note:** Version bump only for package assu-css





## [1.0.2](https://sources.assu.socgen/sms/framework-js/compare/v1.0.1...v1.0.2) (2020-04-09)

**Note:** Version bump only for package assu-css





## 1.0.1 (2020-04-09)

**Note:** Version bump only for package assu-css
